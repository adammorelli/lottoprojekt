# lottoprojekt
- Máté
css
- Csanád
html
- Misi
képek
- Weboldal elérése: https://szaszuge.github.io/lottoprojekt/
